//Events 

//Loading page
document.addEventListener('DOMContentLoaded', loadInventory);


// Form submission handler
document.getElementById('inventoryForm').addEventListener('submit', function(event) {
    event.preventDefault();
    /*event.preventDefault() is a method in JavaScript that is used to 
    stop the default behavior of an event from happening. */

    const itemName = document.getElementById('itemName').value.toUpperCase();
    const stockQty = parseInt(document.getElementById('itemQuantity').value) || 0;
    const targetQty = parseInt(document.getElementById('targetQty').value) || 0;
    const imageFile = document.getElementById('itemImage').files[0]; // Get the uploaded image file

    if (itemName && !isNaN(stockQty) && !isNaN(targetQty)) {
        addItemToInventory(itemName, stockQty, targetQty, imageFile);
        document.getElementById('inventoryForm').reset(); // Reset the form
    } else {
        alert('Please fill out all fields with valid numbers.');
    }
   
    saveInventory();
});

// Generate Report Button
document.getElementById('report').addEventListener('click', function() {
    // Update quantities
    const reportDetails = updateQuantities();

    // Display report message
    const reportMessage = document.getElementById('reportMessage');
    const currentTime = new Date().toLocaleString();

    // Check if there are valid changes
    if (reportDetails.length > 0) {
        // Update the report if there are changes
        reportMessage.innerHTML = `<b>Table was updated at ${currentTime}</b><br><hr>${reportDetails.join('<br>')}`;
        saveInventory(); // Save only if there are changes
        // Store the latest meaningful report
        localStorage.setItem('lastReport', reportMessage.innerHTML);
    } else {
        // If no changes, keep the last meaningful report
        const lastReport = localStorage.getItem('lastReport');
        if (lastReport) {
            reportMessage.innerHTML = lastReport; // Display the last report
        } else {
            reportMessage.innerHTML = `<b>No meaningful changes detected. Last update at ${currentTime}</b>`;
        }
    }
   
    saveInventory();
});

// Logout button functionality
document.getElementById('logout-button').addEventListener('click', function() {
    alert('Logging out...');
    // Perform logout actions (clear session, redirect, etc.)
    window.location.href = 'index.html'; // Redirect to login page
});
//Events


// Function to add an item to the inventory table
function addItemToInventory(name, stockQty, targetQty, imageFile,imageUrl) {
    const table = document.getElementById('inventoryBody');
    const newRow = table.insertRow();

    const cell1 = newRow.insertCell(0); // Item Name
    const cell2 = newRow.insertCell(1); // Target Qty (editable)
    const cell3 = newRow.insertCell(2); // Stock Qty (non-editable)
    const cell4 = newRow.insertCell(3); // Need Qty (calculated)
    const cell5 = newRow.insertCell(4); // Sold Qty (editable)
    const cell6 = newRow.insertCell(5); // Add Qty (editable)
    const cell7 = newRow.insertCell(6); // Image
    const cell8 = newRow.insertCell(7); // Delete

    // Item Name (fixed text)
    cell1.textContent = name;

    // Target Qty (editable)
    const targetInput = document.createElement('input');
    targetInput.type = 'text';
    targetInput.value = targetQty;
    targetInput.classList.add('edit-input');
    cell2.appendChild(targetInput);

    // Stock Qty (non-editable)
    cell3.textContent = stockQty;

    // Need Qty (calculated, non-editable)
    const needQty = document.createElement('span');
    const needValue=calculateNeedQty(targetQty, stockQty);
    needQty.textContent = needValue;
    if(needValue>0){
        needQty.style.color='red';
    }
    cell4.appendChild(needQty);

    // Sold Qty (editable)
    const soldQtyInput = document.createElement('input');
    soldQtyInput.type = 'text';
    soldQtyInput.value = 0;
    cell5.appendChild(soldQtyInput);

    // Add Qty (editable)
    const addQtyInput = document.createElement('input');
    addQtyInput.type = 'text';
    addQtyInput.value = 0;
    cell6.appendChild(addQtyInput);

    // Image
    const image = document.createElement('img');
    if (imageFile) {
        // If an image file is provided (for user-uploaded images)
        const imageUrl = URL.createObjectURL(imageFile); // Create a URL for the uploaded image
        image.src = imageUrl;
    } else {
        // If no image is provided, use a placeholder
        image.src = imageUrl || 'https://via.placeholder.com/50?text=No+Image';
    }
    image.style.width = '50px'; // Set image size
    image.style.height = '50px';
    image.style.objectFit='contain';//Maintain aspect ratio without cropping
    
    if (imageFile) {
        // Convert image to Base64
        const reader = new FileReader();
        reader.onload = function (e) {
            image.src = e.target.result;
            saveInventory(); // Ensure image is saved after conversion
        };
        reader.readAsDataURL(imageFile);
    } else {
        // Use provided URL or placeholder
        image.src = imageUrl || 'https://via.placeholder.com/50?text=No+Image';
    }
    cell7.appendChild(image);

        // Delete Button
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.classList.add('delete-btn');
    deleteButton.addEventListener('click', function() {
        // Get the item name from the row
        const itemName = newRow.cells[0].textContent;
        const confirmDelete = window.confirm(`Are you sure you want to delete "${itemName}"?`);
        if (confirmDelete) {
            table.deleteRow(newRow.rowIndex - 1);
            deleteFromInventory(itemName);
        }
    });
    cell8.appendChild(deleteButton);

}

// Helper function to delete an item from localStorage
function deleteFromInventory(itemName) {
    const savedData = localStorage.getItem('inventoryData');
    if (savedData) {
        const inventoryData = JSON.parse(savedData);

        // Filter out the item to be deleted
        const updatedInventory = inventoryData.filter(item => item.itemName !== itemName);

        // Save the updated inventory back to localStorage
        localStorage.setItem('inventoryData', JSON.stringify(updatedInventory));
    }
}

// Function to calculate Need Qty
function calculateNeedQty(targetQty, stockQty) {
    return Math.max(0, targetQty - stockQty);
}


// Function to update stock and need quantities
function updateQuantities() {
    const table = document.getElementById('inventoryBody');
    const rows = table.rows;

    let reportDetails = [];

    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const itemName = row.cells[0].textContent;
        const targetQty = parseInt(row.cells[1].querySelector('input').value) || 0;
        const previousStockQty = parseInt(row.cells[2].textContent) || 0;
        const soldQtyInput = row.cells[4].querySelector('input');
        const addQtyInput = row.cells[5].querySelector('input');
        const soldQty = parseInt(soldQtyInput.value) || 0;
        const addQty = parseInt(addQtyInput.value) || 0;

        // Update Stock Qty
        const newStockQty = previousStockQty + addQty - soldQty;
        row.cells[2].textContent = newStockQty;

        // Update Need Qty
        const needQty = calculateNeedQty(targetQty, newStockQty);
        row.cells[3].querySelector('span').textContent = needQty;

        // Apply color conditions
        if (newStockQty > targetQty) {
            row.cells[2].style.color = 'orange'; // Stock Qty orange if greater than Target
        } else {
            row.cells[2].style.color = 'black'; // Reset to default
        }

        if (needQty > 0) {
            row.cells[3].querySelector('span').style.color = 'red'; // Need Qty red if greater than 0
        } else {
            row.cells[3].querySelector('span').style.color = 'black'; // Reset to default
        }

         // Only add report if soldQty or addQty are not both 0
         if (soldQty !== 0 || addQty !== 0) {
            reportDetails.push(`${itemName}: Previous Stock=${previousStockQty}, Sold=${soldQty}, Added=${addQty}`);
        }
        // Reset Sold Qty and Add Qty to 0
        soldQtyInput.value = 0;
        addQtyInput.value = 0;
    }

    return reportDetails;
}



// Helper function to convert image to Base64
function imageToBase64(file, callback) {
    const reader = new FileReader();
    reader.onloadend = () => callback(reader.result);
    reader.readAsDataURL(file);
}


//save data to localStorage 
function saveInventory() {
    const inventoryData = [];
    const rows = document.querySelectorAll('#inventoryTable tbody tr');

    rows.forEach(row => {
        const itemName = row.cells[0].textContent;
        const stockQty = parseInt(row.cells[2].textContent) || 0;
        const targetQty = parseInt(row.cells[1].querySelector('input').value) || 0;
        const imgElement = row.cells[6].querySelector('img');

        const imageUrl = imgElement.getAttribute('src');

        
        console.log("Saving image URL:", imageUrl); // 🔍 Log the stored path

        inventoryData.push({ itemName, stockQty, targetQty, imageUrl });
    });

    localStorage.setItem('inventoryData', JSON.stringify(inventoryData));
}


//load saved data to page 
function loadInventory() {
    const savedData = localStorage.getItem('inventoryData');
    if (savedData) {
        const inventoryData = JSON.parse(savedData);
        inventoryData.forEach(item => {
            console.log("Loading image URL:", item.imageUrl); // 🔍 Log t
            addItemToInventory(item.itemName, item.stockQty, item.targetQty, null, item.imageUrl);
        });
    }
}



/*document.getElementById('logout-button').addEventListener('click', function() {
    alert('Logging out...');
    localStorage.removeItem('inventoryData'); // Clear saved inventory
    window.location.href = 'index.html'; // Redirect to login page
});*/
