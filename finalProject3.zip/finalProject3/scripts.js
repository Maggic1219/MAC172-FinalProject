function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Hardcoded credentials (for simplicity)
    if (username === 'admin' && password === '1234') {
        window.location.href = 'inventory.html'; // Redirect to inventory page
    } else {
        document.getElementById('error').textContent = 'Invalid credentials. Try again.';
    }
}